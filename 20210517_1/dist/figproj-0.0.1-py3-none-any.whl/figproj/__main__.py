from . import solve, fig

a, b = map(float, input("Input a b: ").split())
print(fig(solve(a, b)))

